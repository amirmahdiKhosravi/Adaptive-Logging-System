
# Responsive Migration

As we plot a course to migrate allura's default layout to be responsive, new templates can be placed in this directory to supercede their legacy counterparts.

To see the overridden templates take effect, ensure `disable_entry_points.allura.theme.override = responsive` is *disabled* (by commenting out or removing entirely) in your INI file.  