---
name: Feature request
about: Idea or feature request
title: ''
labels: 'kind:feature'
assignees: ''

---

<!--
Hi! We are happy that you are using Kibble.
Please follow below steps when submitting the issue.
Check our other issues -- maybe similar feature is already reported.

Please, delete comment block before submitting.

Thank you and have a nice day!
Kibble team
-->

**Description**
<!-- Provide description of your idea/feature. -->

**Use case**
<!--
What do you want to achieve with this idea?
Please tell us about your idea as much as possible.
Focus on the user perspective rather than implementation.
What problem do you want to solve with your idea.
-->

**Related Issues**
<!-- Is there any issue related to your idea? -->
