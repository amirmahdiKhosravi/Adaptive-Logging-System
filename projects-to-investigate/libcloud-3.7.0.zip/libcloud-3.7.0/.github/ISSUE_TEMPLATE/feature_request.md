---
name: Feature request or proposal
about: Suggest an idea for this project

---

## Feature Request

Provide detailed information for your feature request or proposal, including
why you think it's a good idea and how it would benefit Libcloud users and
the broader community.

For more information on contributing, please see https://libcloud.readthedocs.io/en/latest/development.html
