<details>

<summary>
  Raw <code>pip-audit</code> output
</summary>

```
$output
```

</details>
