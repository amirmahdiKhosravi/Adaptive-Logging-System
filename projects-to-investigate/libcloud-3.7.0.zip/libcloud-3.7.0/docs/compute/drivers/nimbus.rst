Nimbus Driver Documentation
===========================

Nimbus driver is based on the Amazon EC2 driver so Amazon EC2 specific
documentation, please refer to :doc:`EC2 Driver Documentation <ec2>` page.

API Docs
--------

.. autoclass:: libcloud.compute.drivers.ec2.NimbusNodeDriver
    :members:
    :inherited-members:
