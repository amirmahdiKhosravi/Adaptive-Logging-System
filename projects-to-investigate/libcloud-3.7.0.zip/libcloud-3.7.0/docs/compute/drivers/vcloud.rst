VMware vCloud Driver Documentation
==================================

.. figure:: /_static/images/provider_logos/vmware.png
    :align: center
    :width: 300
    :target: http://www.vmware.com/products/vcloud-suite/

API Docs
--------

.. autoclass:: libcloud.compute.drivers.vcloud.VCloudNodeDriver
    :members:
    :inherited-members:
