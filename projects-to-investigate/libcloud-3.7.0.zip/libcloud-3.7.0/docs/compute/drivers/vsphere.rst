VMware vSphere Compute Driver Documentation
===========================================

.. note::

   VMware vSphere driver relies on ``pysphere`` library which is unmaintained
   and doesn't support Python 3.

   Libcloud v3.0.0 removed supprt for Python versions older than v3.5.0 and as
   such, vSphere driver was removed.

   If you still need to use that driver, you can use latest Libcloud release
   which still supports Python 2.7 (Libcloud v2.8.0).
