:orphan:

Container Base API
==================

.. autoclass:: libcloud.container.base.ContainerDriver
    :members:

.. autoclass:: libcloud.container.base.Container
    :members:

.. autoclass:: libcloud.container.base.ContainerImage
    :members:

.. autoclass:: libcloud.container.base.ContainerCluster
    :members:

.. autoclass:: libcloud.container.base.ClusterLocation
    :members:
