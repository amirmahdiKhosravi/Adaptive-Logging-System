:orphan:

Container Utility API
=====================

.. autoclass:: libcloud.container.utils.docker.RegistryClient
    :members:

.. autoclass:: libcloud.container.utils.docker.HubClient
    :members:
