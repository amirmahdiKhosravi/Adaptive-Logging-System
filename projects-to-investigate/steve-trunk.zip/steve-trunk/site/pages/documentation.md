Title: Index

 * [List of implemented vote types](vote_types.html)
 * [Getting started with pySTeVe](demo.html)
